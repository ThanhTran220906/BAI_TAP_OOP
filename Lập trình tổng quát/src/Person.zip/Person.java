import java.util.Objects;

public class Person implements Week11 {
    protected String name;
    protected int age;
    protected String address;

    public Person() {
        age = 0;
    }

    public Person(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int compareTo(Person p) {
        int nameCompare = this.name.compareToIgnoreCase(p.name);
        if (nameCompare != 0) {
            return nameCompare;
        } else {
            return Integer.compare(this.age, p.age);
        }
    }
}
